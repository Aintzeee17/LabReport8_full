// === Mobile Nav Toggle ===
const toggleBtn = document.querySelector('.mobile-nav-toggle');
toggleBtn.addEventListener('click', () => {
  document.body.classList.toggle('mobile-nav-active');
  toggleBtn.querySelector('i').classList.toggle('bi-list');
  toggleBtn.querySelector('i').classList.toggle('bi-x');
});

// Close mobile menu when link clicked
document.querySelectorAll('header nav ul li a').forEach(link => {
    link.addEventListener('click', () => {
        if (document.body.classList.contains('mobile-nav-active')) {
            document.body.classList.remove('mobile-nav-active');
            mobileNavToggle.classList.add('bi-list');
            mobileNavToggle.classList.remove('bi-x');
        }
    });
});

// === Scrollspy Active Link ===
const navLinks = document.querySelectorAll('header nav ul li a');
window.addEventListener('scroll', () => {
    let fromTop = window.scrollY + 200;
    navLinks.forEach(link => {
        let section = document.querySelector(link.hash);
        if (!section) return;
        if (fromTop >= section.offsetTop && fromTop <= section.offsetTop + section.offsetHeight) {
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
});

// === Scroll to Top Button ===
const scrollTopBtn = document.querySelector('.scroll-top');
if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
        window.scrollY > 100 ? scrollTopBtn.classList.add('active') : scrollTopBtn.classList.remove('active');
    });

    scrollTopBtn.addEventListener('click', e => {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// === AOS Init ===
document.addEventListener('DOMContentLoaded', () => {
    if (typeof AOS !== 'undefined') {
        AOS.init({
            duration: 600,
            easing: 'ease-in-out',
            once: true
        });
    }
});

// === GLightbox Init ===
if (typeof GLightbox !== 'undefined') {
    GLightbox({ selector: '.glightbox' });
}
